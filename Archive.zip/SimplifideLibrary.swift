//
//  SimplifideLibrary.swift
//  Simplifide
//
//  Created by Inversedime on 16/12/16.
//  Copyright © 2016 Simplifide. All rights reserved.
//

import UIKit
import AVFoundation
import LocalAuthentication

@objc enum TouchIdStatus: Int{
    case AuthCanceledBySystem,
    AuthSuccess,
    TouchIdNotAvailable,
    AuthCanceledByUser,
    UserSelectToEnterPassword,
    AuthFailed,
    TouchIDNotEnrolled,
    PasscodeNotSet,
    InfoStatusLabel
}
@objc protocol SimplifideDelegate {
    optional func cameraSessionConfigurationDidComplete()
    optional func cameraSessionDidBegin()
    optional func cameraSessionDidStop()
    optional func audioRecorderFinishRecording(base64string:String,flag:Bool,done:Bool)->Void;
    optional func audioPlayerFinishPlaying()->Void;
    optional func totalRecordTime(timer:String,sec:Int)->Void
    optional func TouchIdAuthenticationDelegate(status:TouchIdStatus)
}
class SimplifideLibrary: NSObject,AVAudioRecorderDelegate,AVAudioPlayerDelegate {
   
    var infoStatus:TouchIdStatus = .InfoStatusLabel
    //var delegate:AudioRecorerPlayerDelegates?;
    var soundRecorder : AVAudioRecorder!
    var SoundPlayer : AVAudioPlayer!
    var fileName = "/audioFile.wav"
    var meterTimer:NSTimer!
    var isRecordingDone:Bool = false
    
    /**----------------- Web Service Call Variable ----------------*/
    var BASE_URL:String! = ""
    var API_KEY:String! = ""
    var API_SECRET:String! = ""
     override init() {
        super.init()
    }
    init(baseUrl:String,apiKey:String,apiSecret:String) {
        
        BASE_URL = baseUrl
        API_KEY = apiKey
        API_SECRET = apiSecret
        
        super.init()
    
    }
    
    
    func getAccountName(url:String)->NSDictionary{
        var aDict = NSDictionary()
        self.getResponse(url as String, failure: { (error) in
            aDict = error
            print(aDict)
            
        }) { (response) in
            aDict = response
            print(aDict)
        }
        return aDict
    }
    
    func requestForOTP(url:String) -> NSDictionary {
      var aDict = NSDictionary()
        self.getResponse(url as String, failure: { (error) in
            aDict = error
            print(aDict)
            
        }) { (response) in
            aDict = response
            print(aDict)
        }
        return aDict
    }
    /**
     Call method when gerister user
     - returns:NSDictionary
     - parameter email:String
     - parameter phone:String
     - parameter accountNum:String
     */
    
    func getUserBiometricDetail(accountId:String,remoteId:String) -> NSDictionary {
        var aDict = NSDictionary()
        //let url = "https://sandbox-api.simplifideinc.com/simplifide_api/v1/accounts/\(accountId)/identities/\(remoteId)"
        
        let url = self.createUrl("\(accountId)/identities/\(remoteId)") as String
        self.getResponse(url, failure: { (error) in
            aDict = error
             print(aDict)
            
            }) { (response) in
                aDict = response
                 print(aDict)
        }
        return aDict
    }
    func callWebServicesForRegisterUser(email:String,phone:String,accountNum:String) -> NSDictionary {
        
        var aDict = NSDictionary()
        let url = self.createUrl("\(accountNum)/identities?mobile=\(phone)&email=\(email)" as NSString)
        
        self.getResponse(url as String, failure: { (error) in
            aDict = error
            print(aDict)
            
            }) { (response) in
                aDict = response
                print(aDict)
        }

        return aDict
    }
    /**
     Call method when verify Device
     - returns:NSDictionary
     - parameter url:String
     */
    func callWebServicesForVerifyDevice(url:String) -> NSDictionary {
        var aDict = NSDictionary()
        self.getResponse(url, failure: { (error) in
            aDict = error
            }) { (response) in
                aDict = response
        }
        return aDict
    }
    /**
     Call method when resend OTP code
     - returns:NSDictionary
     - parameter url:Strin
     */
    func callWebServicesForResendCode(url:String) -> NSDictionary {
        
        var aDict = NSDictionary()
        self.getResponse(url, failure: { (error) in
            aDict = error
        }) { (response) in
            aDict = response
        }
        return aDict
    }
    /**
     Call method when Reverify Device
     - returns:NSDictionary
     - parameter url:Strin
     */
    func callWebServicesForReverifyDevice(url:String) -> NSDictionary {
        
        var aDict = NSDictionary()
        self.getResponse(url, failure: { (error) in
            aDict = error
        }) { (response) in
            aDict = response
        }
        return aDict
    }
    
    func getResponse(url:String,failure:(error:NSDictionary)->Void,complition:(response:NSDictionary)->Void) ->Void {
        let semaphore = dispatch_semaphore_create(0)
        do {
            print(url)
            let url = NSURL(string: url)!
            let request = NSMutableURLRequest(URL: url)
            request.HTTPMethod = "GET"
            request.setValue(API_KEY, forHTTPHeaderField: "api_key")
            request.setValue(API_SECRET, forHTTPHeaderField: "api_secret")
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            
            print(API_KEY)
            print(API_SECRET)
            
            let task = NSURLSession.sharedSession().dataTaskWithRequest(request){ data, response, error in
                dispatch_async(dispatch_get_main_queue(), {
                    
                    //print("Request..... :\(request)")
                    //print("RESPONSE..... :\(response)")
                    if error != nil{
                        let aDict = ["status":"false","code":"Sorry. Unable to process your request. Please try again after some time"]
                        //print("In Error Block:\(error)")
                        //print("In Error Block:\(aDict)")
                        failure(error: aDict as NSDictionary)
                       
                    }
                })
                do {
                    if data != nil || response != nil{
                        let result = try NSJSONSerialization.JSONObjectWithData(data!, options: []) as! NSDictionary
                        let total = result.allKeys.count
                        if total > 0{
                            complition(response: result)
                        }else{
                            let aDict = ["status":"false","code":"Sorry. Unable to process your request. Please try again after some time"]
                            //print("In Catch Block:\(aDict)")
                            complition(response: aDict)
                        }
                    }else{
                        let aDict = ["status":"false","code":"Sorry. Unable to process your request. Please try again after some time"]
                        //print("In Catch Block:\(aDict)")
                        complition(response: aDict)
                    }
                } catch {
                    let aDict = ["status":"false","code":"Sorry. Unable to process your request. Please try again after some time"]
                    //print("In Catch Block:\(aDict)")
                     //print("Error : \(error)")
                    failure(error: aDict as NSDictionary)
                   
                    
                }
                dispatch_semaphore_signal(semaphore)
            }
            task.resume()
            dispatch_semaphore_wait(semaphore, DISPATCH_TIME_FOREVER)
        }
    }
    
    /**
     Call method when verify photo
     - returns:NSDictionary
     - parameter base64Image:String
     - parameter url:String
     - parameter timeStamp:String
     - parameter latitude:String
     - parameter longitude:String
     */
    func callWebServicesVerifyBiomatric(base64Image:String,url:String,timeStamp:String,latitude:String,longitude:String,modality:String,mfaType:String,failure:(errorResponse:NSDictionary)->Void,complition:(successResponse:NSDictionary)->Void) -> Void{
         let semaphore = dispatch_semaphore_create(0)
        let  postString = [
            "biometric":["modality":modality,"biometricsData":base64Image,
                "transactionContext":["timestamp":timeStamp,
                    "latitude":latitude,
                    "longitude":longitude,
                    "eventType":"REMOTE ACCOUNT USER \(modality) VERIFICATION",
                    "interactionChannel":"APP",
                    "mfaOutcome":"SUCCESS",
                    "mfaType":mfaType,
                    "deviceType":deviceInformation(),
                    "deviceBrowser":"Simplifide",
                    "deviceOS":"iOS"]
            ]
            ] as NSDictionary
        

        //print(url)
        //print(deviceInformation())
        print("Post String : \(postString)")
        
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0)) {
            do {
                let jsonData = try NSJSONSerialization.dataWithJSONObject(postString, options:.PrettyPrinted)
                let request = NSMutableURLRequest(URL: NSURL(string: url)!)
                request.HTTPMethod = "POST"

                request.setValue(self.API_KEY, forHTTPHeaderField: "api_key")
                request.setValue(self.API_SECRET, forHTTPHeaderField: "api_secret")
                request.setValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
                request.HTTPMethod = "POST"
                request.HTTPBody = jsonData
                let task = NSURLSession.sharedSession().dataTaskWithRequest(request){ data, response, error in
                    if error != nil{
                        print("Error -> \(error)")
                        let errorDict = ["status":"false","code":"Sorry. Unable to process your request. Please try again after some time"]
                        failure(errorResponse: errorDict)
                        return
                    }
                    do {
                        if data != nil || response != nil{
                            let result = try NSJSONSerialization.JSONObjectWithData(data!, options: []) as! NSDictionary
                            let total =  result.allKeys.count
                            if total>0{
                                dispatch_async(dispatch_get_main_queue(), {
                                    complition(successResponse: result)
                                    
                                })
                            }else{
                                let aDict = ["status":"false","code":"Sorry. Unable to process your request. Please try again after some time"]
                                print("In Catch Block:\(aDict)")
                                complition(successResponse: aDict)
                            }
                            
                        }else{
                            let aDict = ["status":"false","code":"Sorry. Unable to process your request. Please try again after some time"]
                            print("In Catch Block:\(aDict)")
                            complition(successResponse: aDict)
                        }
                        
                    } catch {
                        print("Error -> \(error)")
                        let errorDict = ["status":"false","code":"Sorry. Unable to process your request. Please try again after some time"]
                        failure(errorResponse: errorDict)
                    }
                   dispatch_semaphore_signal(semaphore)
                }
                task.resume()
                dispatch_semaphore_wait(semaphore, DISPATCH_TIME_FOREVER)
            } catch {
                print(error)
                
            }
        }
        
    }
    
    func createUrl(appendLink:NSString) -> NSString {
        return BASE_URL.stringByAppendingString(appendLink as String)
    }

    
 /*------------------- Camera Library --------------------------*/
    
    weak var delegate:SimplifideDelegate?
    var session: AVCaptureSession!
    var sessionQueue: dispatch_queue_t!
    var stillImageOutput: AVCaptureStillImageOutput?
    init(sender: AnyObject) {
        super.init()
        self.delegate = sender as? SimplifideDelegate
        self.setObservers()
        self.initializeSession()
    }
    
    deinit {
        self.removeObservers()
    }
    func initializeSession() {
        self.session = AVCaptureSession()
        self.session.sessionPreset = AVCaptureSessionPresetPhoto
        self.sessionQueue = dispatch_queue_create("camera session", DISPATCH_QUEUE_SERIAL)
        
        dispatch_async(self.sessionQueue) {
            self.session.beginConfiguration()
            self.addVideoInput()
            self.addStillImageOutput()
            self.session.commitConfiguration()
            
            dispatch_async(dispatch_get_main_queue()) {
                NSLog("Session initialization did complete")
                self.delegate?.cameraSessionConfigurationDidComplete!()
            }
        }
    }
    func startCamera() {
        dispatch_async(self.sessionQueue) {
            self.session.startRunning()
        }
    }
    
    func stopCamera() {
        dispatch_async(self.sessionQueue) {
            self.session.stopRunning()
        }
    }
    func captureStillImage(completed: (image: UIImage?) -> Void) {
        if let imageOutput = self.stillImageOutput {
            dispatch_async(self.sessionQueue, { () -> Void in
                
                var videoConnection: AVCaptureConnection?
                for connection in imageOutput.connections {
                    let c = connection as! AVCaptureConnection
                    
                    for port in c.inputPorts {
                        let p = port as! AVCaptureInputPort
                        if p.mediaType == AVMediaTypeVideo {
                            videoConnection = c;
                            break
                        }
                    }
                    
                    if videoConnection != nil {
                        break
                    }
                }
                
                if videoConnection != nil {
                    imageOutput.captureStillImageAsynchronouslyFromConnection(videoConnection, completionHandler: { (imageSampleBuffer: CMSampleBufferRef!, error) -> Void in
                        let imageData = AVCaptureStillImageOutput.jpegStillImageNSDataRepresentation(imageSampleBuffer)
                        let image: UIImage? = UIImage(data: imageData!)!
                        
                        dispatch_async(dispatch_get_main_queue()) {
                            completed(image: image)
                            
                        }
                    })
                } else {
                    dispatch_async(dispatch_get_main_queue()) {
                        completed(image: nil)
                    }
                }
            })
        } else {
            completed(image: nil)
        }
    }
    // MARK: Configuration
    
    func addVideoInput() {
        let device: AVCaptureDevice = self.deviceWithMediaTypeWithPosition(AVMediaTypeVideo, position: AVCaptureDevicePosition.Front)
        do {
            let input = try AVCaptureDeviceInput(device: device)
            if self.session.canAddInput(input) {
                self.session.addInput(input)
            }
        } catch {
            print(error)
        }
    }
    
    func addStillImageOutput() {
        stillImageOutput = AVCaptureStillImageOutput()
        stillImageOutput?.outputSettings = [AVVideoCodecKey: AVVideoCodecJPEG]
        
        if self.session.canAddOutput(stillImageOutput) {
            session.addOutput(stillImageOutput)
        }
    }
    /**
     Call the method when camera rotation is needed (from Front to Back and vice versa)
     - returns:AVCaptureDevice
     - parameter mediaType: NSString (SimplifideLibrary object)
     - parameter mediaType: NSString (SimplifideLibrary object)
     
     */
    func deviceWithMediaTypeWithPosition(mediaType: NSString, position: AVCaptureDevicePosition) -> AVCaptureDevice {
        let devices: NSArray = AVCaptureDevice.devicesWithMediaType(mediaType as String)
        var captureDevice: AVCaptureDevice = devices.firstObject as! AVCaptureDevice
        for device in devices {
            let d = device as! AVCaptureDevice
            if d.position == position {
                captureDevice = d
                
                break;
                
            }
        }
        return captureDevice
    }
    
    /**
     Initilize Back Camera
     - returns:Bool
     */
    func initilizeBackCamera() -> Bool {
        
        
        var success  = false
        
        let device: AVCaptureDevice = (self.deviceWithMediaTypeWithPosition(AVMediaTypeVideo, position: AVCaptureDevicePosition.Back))
        
        do {
            
            let input = try AVCaptureDeviceInput(device: device)
            
            if session.canAddInput(input) {
                
                session.addInput(input)
                
                success = true
                
            }
            
        } catch {
            
            print(error)
            success = false
        }
        
        return success;
    }
 
    /**
     Initilize Front Camera
     - returns:Bool
     */
    func initilizeFrontCamera() -> Bool {
        
        var success  = false
        let device: AVCaptureDevice = (self.deviceWithMediaTypeWithPosition(AVMediaTypeVideo, position: AVCaptureDevicePosition.Front))
        
        do {
            
            let input = try AVCaptureDeviceInput(device: device)
            
            if session.canAddInput(input) {
                
                session.addInput(input)
                 success = true
               
            }
            
        } catch {
            
            print(error)
             success = false
        }
         return success;
    }
    
    /*-------------- MARK: Observers -------------------*/
    
    
    func setObservers() {
        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(SimplifideLibrary.sessionDidStart(_:)), name: AVCaptureSessionDidStartRunningNotification, object: nil)
        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(SimplifideLibrary.sessionDidStop(_:)), name: AVCaptureSessionDidStopRunningNotification, object: nil)
    }
    func removeObservers() {
        NSNotificationCenter.defaultCenter().removeObserver(self)
    }
    
    /*-------------- MARK: Camera Delegates -------------------*/
    
    func sessionDidStart(notification: NSNotification) {
        dispatch_async(dispatch_get_main_queue()) {
            NSLog("Session did start")
            self.delegate?.cameraSessionDidBegin!()
        }
    }
    
    func sessionDidStop(notification: NSNotification) {
        dispatch_async(dispatch_get_main_queue()) {
            NSLog("Session did stop")
            self.delegate?.cameraSessionDidStop!()
        }
    }
    

    
    /**
     Call method when base64 to Image Conversion needed
     - returns:String
     - parameter base64Str:String
     
     */
    
    func base64ToImageConversion(base64Str:String) -> UIImage {
        let imageData = NSData(base64EncodedString: base64Str as String,options:NSDataBase64DecodingOptions.IgnoreUnknownCharacters)
        return UIImage(data: imageData!)!
        
    }
    
    /**
     Call method when Image to base64 Conversion needed
     - returns:String
     - parameter image:UIImage
     */
    func imageToBase64Conversion(image:UIImage) -> String {
        let imageData=UIImagePNGRepresentation(image)! as NSData
        
         return imageData.base64EncodedStringWithOptions(.EncodingEndLineWithLineFeed) as String
    }
    /**
     Call method when Image image resizing is needed
     - returns:UIImage
     - parameter image:UIImage
     - parameter targetSize:CGSize
     */
    func ResizeImage(image: UIImage, targetSize: CGSize) -> UIImage {
        let size = image.size
        
        let widthRatio  = targetSize.width  / image.size.width
        let heightRatio = targetSize.height / image.size.height
        
        // Figure out what our orientation is, and use that to form the rectangle
        var newSize: CGSize
        if(widthRatio > heightRatio) {
            newSize = CGSizeMake(size.width * heightRatio, size.height * heightRatio)
        } else {
            newSize = CGSizeMake(size.width * widthRatio,  size.height * widthRatio)
        }
        
        // This is the rect that we've calculated out and this is what is actually used below
        let rect = CGRectMake(0, 0, newSize.width, newSize.height)
        print(rect)
        
        // Actually do the resizing to the rect using the ImageContext stuff
        UIGraphicsBeginImageContextWithOptions(newSize, false, 1.0)
        image.drawInRect(rect)
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        
        return newImage!
    }
    
    
    /*--------------------------Start Audio Recording --------------------------------*/
    
    func setupRecorder() {
        /*let recordSettings = [AVSampleRateKey : NSNumber(float: Float(44100.0)),
                              AVFormatIDKey : NSNumber(int: Int32(kAudioFormatAppleLossless)),
                              AVNumberOfChannelsKey : NSNumber(int: 2),
                              AVEncoderAudioQualityKey : NSNumber(int: Int32(AVAudioQuality.Max.rawValue))];*/
        let recordSettings: [String : AnyObject] = [
            AVFormatIDKey:Int(kAudioFormatLinearPCM),
            AVSampleRateKey:44100.0,
            AVNumberOfChannelsKey:1,
            AVLinearPCMBitDepthKey:8,
            AVLinearPCMIsFloatKey:false,
            AVLinearPCMIsBigEndianKey:false,
            AVEncoderAudioQualityKey:AVAudioQuality.Max.rawValue
        ]
        var error: NSError?
        do {
            soundRecorder =  try AVAudioRecorder(URL: getFileURL(), settings: recordSettings)
        } catch let error1 as NSError {
            error = error1
            soundRecorder = nil
        }
        if let err = error {
            print("AVAudioRecorder error: \(err.localizedDescription)")
        } else {
            soundRecorder.delegate = self
            soundRecorder.prepareToRecord()
        }
    }
    func getFileURL() -> NSURL {
        let path = getCacheDirectory().stringByAppendingString(fileName)
        let filePath = NSURL(fileURLWithPath: path)
        return filePath
    }
    func getCacheDirectory() -> String {
        let paths = NSSearchPathForDirectoriesInDomains(NSSearchPathDirectory.DocumentDirectory, NSSearchPathDomainMask.UserDomainMask, true)
        return paths[0]
    }
    func preparePlayer() {
        var error: NSError?
        do {
            SoundPlayer = try AVAudioPlayer(contentsOfURL: getFileURL())
            print(SoundPlayer)
        } catch let error1 as NSError {
            error = error1
            SoundPlayer = nil
        }
        if let err = error {
            print("AVAudioPlayer error: \(err.localizedDescription)")
        } else {
            SoundPlayer.delegate = self
            SoundPlayer.prepareToPlay()
            SoundPlayer.volume = 1.0
        }
    }
    func stopRecording(sender:UIButton) -> Void {

        if let stp = soundRecorder{
            stp.stop()
        }
        
        sender.hidden = true
    }
    func recordSound(sender:UIButton) -> Void {
      
            soundRecorder.record()
            soundRecorder.recordForDuration(15)
            if soundRecorder.recording == true {
                self.meterTimer = NSTimer.scheduledTimerWithTimeInterval(1.0,
                                                                         target:self,
                                                                         selector:#selector(SimplifideLibrary.updateAudioMeter(_:)),
                                                                         userInfo:nil,
                                                                         repeats:true)
            }
        

    }
    func audioRecorderDidFinishRecording(recorder: AVAudioRecorder, successfully flag: Bool) {
        soundRecorder.stop()
        let urlString: String = getFileURL().relativePath!
        
    

        let fileData = NSData.init(contentsOfFile: urlString)
        let base64String = (fileData?.base64EncodedStringWithOptions(.EncodingEndLineWithLineFeed))! as String
        self.delegate?.audioRecorderFinishRecording!(base64String, flag: true, done: true)
    }
    func audioPlayerDidFinishPlaying(player: AVAudioPlayer, successfully flag: Bool) {
        self.delegate?.audioPlayerFinishPlaying!()
    }
    
    func updateAudioMeter(timer:NSTimer) {
        if  self.soundRecorder.recording {
            let dFormat = "%02d"
            let sec:Int = Int(self.soundRecorder.currentTime % 60)
            let s = "\(String(format: dFormat, sec))/15 Sec"
            print(sec)
            counter(sec)
            self.delegate?.totalRecordTime!(s, sec: sec)
            self.soundRecorder.updateMeters()
            if sec >= 15 {
                soundRecorder.stop()
                isRecordingDone = true
            }
            
        }else{
            meterTimer.invalidate()
        }
        
    }
    func counter(sec:Int) -> Int {
        
        return sec
    }
    
/*--------------------------End Audio Recording --------------------------------*/
    
    /*--------------------------Stast Touch Authentication --------------------------------*/
   func authenticateUserByTouchId(){
        let context = LAContext()
        var error: NSError?
        let reasonString = "Please place your fingertip on the scanner to verify your identity!"
        if context.canEvaluatePolicy(LAPolicy.DeviceOwnerAuthenticationWithBiometrics, error: &error){
            context.evaluatePolicy(LAPolicy.DeviceOwnerAuthenticationWithBiometrics, localizedReason: reasonString, reply: { (success, policyError) -> Void in
                if success{
                    self.infoStatus = .AuthSuccess
                    self.delegate?.TouchIdAuthenticationDelegate!(self.infoStatus)
                }else{
                    switch policyError!.code{
                    case LAError.SystemCancel.rawValue:
                        self.infoStatus = .AuthCanceledBySystem
                    case LAError.UserCancel.rawValue:
                        self.infoStatus = .AuthCanceledByUser
                    case LAError.UserFallback.rawValue:
                        self.infoStatus = .UserSelectToEnterPassword
                    case LAError.TouchIDNotEnrolled.rawValue:
                        self.infoStatus = .TouchIDNotEnrolled
                    case LAError.PasscodeNotSet.rawValue:
                        self.infoStatus = .PasscodeNotSet
                    default:
                        self.infoStatus = .AuthFailed
                    }
                    self.delegate?.TouchIdAuthenticationDelegate!(self.infoStatus)
                }
            })
        }else{
            print(error?.localizedDescription)
            self.infoStatus = .TouchIdNotAvailable
            self.delegate?.TouchIdAuthenticationDelegate!(self.infoStatus)
            
        }
    }
    
    /*--------------------------End Touch Authentication --------------------------------*/
    
    
}
extension SimplifideLibrary{
    
    func deviceInformation() -> String {
        let deviceName  = UIDevice.currentDevice().name
        return deviceName.stringByReplacingOccurrencesOfString("’", withString: "")
    }
}


extension UIImage {
    func fixedOriantation() -> UIImage {
        if self.imageOrientation == UIImageOrientation.Up {
            return self
        }
        UIGraphicsBeginImageContextWithOptions(self.size, false, self.scale)
        self.drawInRect(CGRectMake(0, 0, self.size.width, self.size.height))
        let normalizedImage:UIImage = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        return normalizedImage;
    }
}

extension String{
    func imageToBase64Conversion(image:UIImage) -> String {
        let imageData=UIImagePNGRepresentation(image)! as NSData
        
        return imageData.base64EncodedStringWithOptions(.EncodingEndLineWithLineFeed) as String
    }
}



