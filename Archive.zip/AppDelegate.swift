//
//  AppDelegate.swift
//  Simplifide
//
//  Created by Optiquall Solutione on 12/09/16.
//  Copyright © 2016 Simplifide. All rights reserved.
//

import CoreLocation
import MapKit
import UIKit
import CoreData


@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate,CLLocationManagerDelegate{

    var locationManager = CLLocationManager()
    var startLocation: CLLocation!
    var window: UIWindow?
    func application(application: UIApplication, didFinishLaunchingWithOptions launchOptions: [NSObject: AnyObject]?) -> Bool {
     
        
        let user = SimplifideUser()
        if user.isJailBreak() {
            
            dispatch_async(dispatch_get_main_queue()) {
                
                let alertController = UIAlertController(title:"Alert" as String, message: APPConstants.ALER_MSG_JAILBREAK_DEVICE as String, preferredStyle: .Alert)
                let yesAction = UIAlertAction(title: "OK", style: .Destructive) { (action) -> Void in
                    exit(0)
                }
                alertController.addAction(yesAction)
                self.window?.rootViewController?.presentViewController(alertController, animated: true, completion: nil)
            }

       }else{
            if UIDevice.currentDevice().userInterfaceIdiom == UIUserInterfaceIdiom.Pad {
                
                NSUserDefaults.standardUserDefaults().setValue("yes", forKey: "ipad")
            }else{
                NSUserDefaults.standardUserDefaults().removeObjectForKey("ipad")
            }
 
            IMEIString()
            dateAndTimeStamp()
            databasePath()
            createSimplifideUser()
            createSimplifideAccount()
            createSimplifideUserAccount()
        }
    
return true
    }
    /*
        Funaction Name:func createDataBase()->NSString
        Purpose : Create Database
        Parameter : NULL
        Return : NSString dbPath
     */
    
    func databasePath()->NSString{
        

        let filemanager = NSFileManager.defaultManager()
        
        let directory:AnyObject=NSSearchPathForDirectoriesInDomains(.DocumentDirectory, .UserDomainMask, true)[0];
        
        let dbPath:NSString = directory.stringByAppendingString("/simplifide_db.sqlite")
        
        if(filemanager.fileExistsAtPath(dbPath as String) )
        {
            print("Database Already Exist...!!!")
             print(dbPath)
            return dbPath;
            
        }
        return dbPath
    }
    
    /*
     Funaction Name:func  createSimplifideUser() -> Void
     Purpose : Create sf_user table
     Parameter : NULL
     Return : Void
     */
    
    func createSimplifideUser() -> Void {
        let createSQL = "CREATE TABLE IF NOT EXISTS sf_user(" +
            "user_id INTEGER PRIMARY KEY AUTOINCREMENT," +
            "first_name VARCHAR(50) NOT NULL," +
            "last_name VARCHAR(50) NOT NULL," +
            "user_email VARCHAR(20) NOT NULL," +
            "user_phone VARCHAR(20) NOT NULL," +
            "remote_user_id VARCHAR(20) NOT NUll," +
            "user_created_date VARCHAR(20) NOT NULL);"
        
        var errMsg:UnsafeMutablePointer<Int8> = nil
        if sqlite3_exec(connect(), createSQL, nil, nil, &errMsg) != SQLITE_OK {
            
            print(errMsg)
        }
        else{
            print("Table to created ...!!!")
        }
    }
    /**Purpose : Create sf_account table
     
    - parameter : NULL
     
    - Return : Void
     
     */
    
    func  createSimplifideAccount() -> Void {
        let createSQL = "CREATE TABLE IF NOT EXISTS sf_account(" +
            "account_id INTEGER PRIMARY KEY AUTOINCREMENT," +
            "account_number VARCHAR(50) NOT NULL);"
        
        
        var errMsg:UnsafeMutablePointer<Int8> = nil
        if sqlite3_exec(connect(), createSQL, nil, nil, &errMsg) != SQLITE_OK {
            
            print(errMsg)
        }
        else{
            print("Created!!!")
            
        }
    }
    
    /*
     Funaction Name:createSimplifideUserAccount()
     Purpose : Create sf_user_account table
     Parameter : NULL
     Return : Void
     */
    func  createSimplifideUserAccount() -> Void {
        let createSQL = "CREATE TABLE IF NOT EXISTS sf_user_account(" +
            "id INTEGER PRIMARY KEY AUTOINCREMENT," +
            "user_id INT NOT NULL," +
            "account_id INT NOT NULL," +
            "trusted_device_key TEXT," +
            "first_name VARCHAR(50) NOT NULL," +
            "last_name VARCHAR(50) NOT NULL," +
            "account_number VARCHAR(50) NOT NULL," +
            "account_verify_date VARCHAR(50) NOT NULL," +
            "account_user_image TEXT NOT NULL," +
            "account_user_device VARCHAR(50) NOT NULL," +
            "trusted_device_expration_date VARCHAR(50) NOT NULL," +
            "account_name VARCHAR (50) NOT NULL," +
            "remote_account_id VARCHAR(20) NOT NULL);"
        var errMsg:UnsafeMutablePointer<Int8> = nil
        if sqlite3_exec(connect(), createSQL, nil, nil, &errMsg) != SQLITE_OK {
            print(errMsg)
        }
        else{
            print("Created!!!")
        }
    }
    
    /*
     Funaction Name:func connect() -> COpaquePointer
     Purpose : Open database and return address of table or database to the calling function "createSimplifideUser"
     Parameter : NULL
     Return : COpaquePointer database
     */
    
    func connect() -> COpaquePointer {
        var database:COpaquePointer=nil
        if sqlite3_open(databasePath().UTF8String, &database) == SQLITE_OK {
            print("Successfully opened connection to database at ")
            return database
        }else{
            print("Unable to open database. Verify that you created the directory described " + "in the Getting Started section.")
            return database
        }
    }
    /*
     Funaction Name:func insertsf_user(user_email:NSString,user_phone:NSString) -> Bool
     Purpose : Add user details in sf_user Table. Details like : user_id,user_email,user_phone and             user_created_datetime. If data insertion is succeed it will return true value
     Parameter : NSString user_email, NSString user_phone
     Return : Bool true
     */
    func insertsf_user(firstName:NSString,lastName:NSString,userEmail:NSString,userPhone:NSString,remoteUserId:NSString) -> Bool {
        let uEmail = user.AESEncrypt(user.key, iv: user.iv, value: userEmail as String)
        let uPhone = user.AESEncrypt(user.key, iv: user.iv, value: userPhone as String)
        var queryStatement: COpaquePointer =  nil
        let queryStatementString = "SELECT * FROM sf_user as u WHERE u.user_email = \"\(uEmail)\" AND u.user_phone = \"\(uPhone)\";"
        if sqlite3_prepare_v2(gblAppDelegate.connect(), queryStatementString, -1, &queryStatement, nil) == SQLITE_OK {
            if sqlite3_step(queryStatement) == SQLITE_ROW {
                user.userId = sqlite3_column_int(queryStatement, 0)
                print(user.userId)
                sqlite3_finalize(queryStatement)
                return true
            }
        }
        var insertStatement: COpaquePointer = nil
        let insertStatementString = "INSERT INTO sf_user(first_name,last_name,user_email,user_phone,remote_user_id,user_created_date) VALUES (?, ?, ?, ?, ?, ?);"
        
        if sqlite3_prepare(gblAppDelegate.connect(), insertStatementString, -1, &insertStatement, nil) == SQLITE_OK {
            let fname = user.AESEncrypt(user.key, iv: user.iv, value: firstName as String)
            let lname = user.AESEncrypt(user.key, iv: user.iv, value: lastName as String)
            let email = user.AESEncrypt(user.key, iv: user.iv, value: userEmail as String)
            let remoteId = user.AESEncrypt(user.key, iv: user.iv, value: remoteUserId as String)
            let phone = user.AESEncrypt(user.key, iv: user.iv, value: userPhone as String)
            sqlite3_bind_text(insertStatement, 1, NSString(string: fname).UTF8String, -1, nil)
            sqlite3_bind_text(insertStatement, 2, NSString(string: lname).UTF8String, -1, nil)
            sqlite3_bind_text(insertStatement, 3, NSString(string: email).UTF8String, -1, nil)
            sqlite3_bind_text(insertStatement, 4, NSString(string: phone).UTF8String, -1, nil)
            sqlite3_bind_text(insertStatement, 5, NSString(string: remoteId).UTF8String, -1, nil)
            sqlite3_bind_text(insertStatement, 6, currentDateTime().UTF8String, -1, nil)
            if sqlite3_step(insertStatement) == SQLITE_DONE	{
                print("inserted")
                let queryStatementString = "SELECT MAX(user_id) FROM sf_user;"
                var queryStatement: COpaquePointer = nil
                if sqlite3_prepare_v2(gblAppDelegate.connect(), queryStatementString, -1, &queryStatement, nil) == SQLITE_OK {
                    while sqlite3_step(queryStatement) == SQLITE_ROW {
                        let lastId = sqlite3_column_int(queryStatement, 0)
                        print(lastId)
                        user.userId = lastId
                       //sqlite3_finalize(queryStatement)
                    }
                }
                sqlite3_finalize(insertStatement)
                sqlite3_close(connect())
                return true
            }else{
                print("not inserted")
                return false
            }
         }else{
            print("INSERT statement could not be prepared.")
            return false
 
        }

}
    
    /*
     Funaction Name:func insertsf_account
     Purpose : Add record in sf_account table
     Parameter : NSString accountNumber
     Return : Bool true
     */
    func insertsf_account(accountNumber:NSString) -> Bool {
        print(accountNumber)
        var insertStatement: COpaquePointer =  nil
        let insertStatementString = "INSERT INTO sf_account(account_number) VALUES (?);"
       if sqlite3_prepare(connect(), insertStatementString, -1, &insertStatement, nil) == SQLITE_OK {
        let account = user.AESEncrypt(user.key, iv: user.iv, value: accountNumber as String)
        sqlite3_bind_text(insertStatement, 1, NSString(string:account).UTF8String, -1, nil)
            print(insertStatement)
        if sqlite3_step(insertStatement) == SQLITE_DONE {
            print("Inserted")
            let queryStatementString = "SELECT MAX(account_id) FROM sf_account;"
            var queryStatement: COpaquePointer = nil
            if sqlite3_prepare_v2(gblAppDelegate.connect(), queryStatementString, -1, &queryStatement, nil) == SQLITE_OK {
                while sqlite3_step(queryStatement) == SQLITE_ROW {
                    let lastAccountId = sqlite3_column_int(queryStatement, 0)
                    print(lastAccountId)
                    user.accountId = lastAccountId
                }
                sqlite3_finalize(queryStatement)
                sqlite3_close(connect())
            }
            sqlite3_finalize(insertStatement)
            sqlite3_close(connect())
            return true
        }
        else{
            print("Insertion Failed")
            let errorMessage = String.fromCString(sqlite3_errmsg(connect()))!
            print(errorMessage)
            return false
        }
       }
       else{
        print("INSERT statement could not be prepared.")
        return false
        }
    }

    /*
     Funaction Name:func insertsf_user_account
     Purpose : Add record in sf_user_account table
     Parameter : NSString trustDeviceKey, NSString accountNumber, NSString accountUserImage, NSString accountUserDevice, NSString exprationDate
     Return : Bool true
     "first_name VARCHAR(50) NOT NULL," +
     "last_name VARCHAR(50) NOT NULL," +
     */
    func insertsf_user_account(accountNumber:NSString,accountUserImage:NSString,accountUserDevice:NSString, exprationDate:NSString,firstName:NSString,lastName:NSString,accName:NSString,remoteAccId:NSString) -> Bool {
        print("Acc Number = \(accountNumber)")
         print("Acc Number = \(accountNumber)")
        var insertStatement: COpaquePointer =  nil
        let insertStatementString = "INSERT INTO sf_user_account(user_id,account_id, trusted_device_key,first_name,last_name, account_number, account_verify_date, account_user_image, account_user_device, trusted_device_expration_date,account_name,remote_account_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);"
        if sqlite3_prepare(gblAppDelegate.connect(), insertStatementString, -1, &insertStatement, nil) == SQLITE_OK {
        let accNumber = user.AESEncrypt(user.key, iv: user.iv, value: accountNumber as String)
        //let userImage = user.AESEncrypt(user.key, iv: user.iv, value: accountUserImage as String)
            sqlite3_bind_int(insertStatement, 1, user.userId)
            sqlite3_bind_int(insertStatement, 2, user.accountId)
            sqlite3_bind_text(insertStatement,3, self.genrateTrustKey().UTF8String, -1, nil)
            sqlite3_bind_text(insertStatement, 4, NSString(string:firstName).UTF8String, -1, nil )
            sqlite3_bind_text(insertStatement, 5, NSString(string:lastName).UTF8String, -1, nil )
            sqlite3_bind_text(insertStatement, 6, NSString(string:accNumber).UTF8String, -1, nil)
            sqlite3_bind_text(insertStatement, 7, currentDateTime().UTF8String, -1, nil)
            sqlite3_bind_text(insertStatement, 8, accountUserImage.UTF8String, -1, nil)
            sqlite3_bind_text(insertStatement, 9, accountUserDevice.UTF8String, -1, nil)
            sqlite3_bind_text(insertStatement, 10, exprationDate.UTF8String, -1, nil)
            sqlite3_bind_text(insertStatement, 11, NSString(string:accName).UTF8String, -1, nil)
            sqlite3_bind_text(insertStatement, 12, NSString(string:remoteAccId).UTF8String, -1, nil)
            if sqlite3_step(insertStatement) == SQLITE_DONE {
                print("Inserted")
                sqlite3_finalize(insertStatement)
                sqlite3_close(connect())
                return true
            }
            else{
                print("Insertion Failed")
                return false
            }
        }else{
            print("INSERT statement could not be prepared.")
            return false
        }
    }
    /*
     Funaction Name:func currentDateTime() -> NSString
     Purpose : Generate Current Date&Time
     
     Parameter : NULL
     Return : NSString dateformatter.stringFromDate(NSDate())
     */
    func validateSFUserAccountData(email:NSString,mobileNum:NSString,accountNum:NSString) -> Bool {
        
        let uEmail = user.AESEncrypt(user.key, iv: user.iv, value: email as String)
        let uPhone = user.AESEncrypt(user.key, iv: user.iv, value: mobileNum as String)
        let uAccount = user.AESEncrypt(user.key, iv: user.iv, value: accountNum as String)
        
        let queryStatementString = "SELECT * FROM sf_user as u,sf_user_account as acc,sf_account as a WHERE u.user_id=acc.user_id AND acc.account_id = a.account_id AND u.user_email = \"\(uEmail)\" AND u.user_phone = \"\(uPhone)\" AND a.account_number = \"\(uAccount)\";"
        var queryStatement: COpaquePointer = nil
        if sqlite3_prepare_v2(gblAppDelegate.connect(), queryStatementString, -1, &queryStatement, nil) == SQLITE_OK {
            if sqlite3_step(queryStatement) == SQLITE_ROW {
                sqlite3_finalize(queryStatement)
                sqlite3_close(connect())
                return true
            }
        }
        return false
    }
    /*
     Funaction Name:func validateEmailAndPhoneNotAccountNum
     Purpose : Check againest data base whether the email,phone and account already exist or not
     Parameter : NSString email, NSString mobileNum, NSString accountNumber
     Return : Bool true
     */
    func validateEmailAndPhoneNotAccountNum(email:NSString,mobileNum:NSString,accountNum:NSString) -> Bool {
        let uEmail = user.AESEncrypt(user.key, iv: user.iv, value: email as String)
        let uPhone = user.AESEncrypt(user.key, iv: user.iv, value: mobileNum as String)
        let uAccount = user.AESEncrypt(user.key, iv: user.iv, value: accountNum as String)
        let queryStatementString = "SELECT * FROM sf_user as u,sf_user_account as acc,sf_account as a WHERE u.user_id=acc.user_id AND acc.account_id = a.account_id AND u.user_email = \"\(uEmail)\" AND u.user_phone = \"\(uPhone)\" AND a.account_number != \"\(uAccount)\";"
        var queryStatement: COpaquePointer = nil
        
        if sqlite3_prepare_v2(gblAppDelegate.connect(), queryStatementString, -1, &queryStatement, nil) == SQLITE_OK {
            if sqlite3_step(queryStatement) == SQLITE_ROW {
                sqlite3_finalize(queryStatement)
                
                return true
            }
        }
        return false
    }
    
    /*
     Funaction Name:update
     Purpose : Update the previous image with lates image according to user id
     Parameter : String image , Int32 id
     Return : String success
     */
    func update(image:String,id:Int32)->String {
        
        var success = "no"
        let updateStatementString = "UPDATE sf_user_account SET account_user_image = \"\(image)\" WHERE user_id = \"\(id)\";"
        var updateStatement: COpaquePointer = nil
        if sqlite3_prepare_v2(connect(), updateStatementString, -1, &updateStatement, nil) == SQLITE_OK {
            if sqlite3_step(updateStatement) == SQLITE_DONE {
                
                success = "yes"
            } else {
                success = "no"
            }
        } else {
            print("UPDATE statement could not be prepared")
        }
        sqlite3_finalize(updateStatement)
        sqlite3_close(connect())
        
        return success
    }
    
    /*
     Funaction Name:updateTrustedKey
     Purpose : Update trusted key,expiryDate,userImage for user and for their particular account when user re-verify their account and check the Trust Device for 30 days
     Parameter : String accid,String uid,String expiryDate,userImage
     Return : String success
     */
    func updateTrustedKey(accid:String,uid:String,expiryDate:String,userimage:String)->String {
        
        let accNumber = user.AESEncrypt(user.key, iv: user.iv, value: accid as String)
        var success = "no"
       // let updateStatementString = "UPDATE sf_user_account SET trusted_device_key=\"\(self.genrateTrustKey())\",account_verify_date=\"\(self.currentDateTime())\",trusted_device_expration_date = \"\(expiryDate)\",account_user_image=\"\(userimage)\" WHERE user_id = \"\(uid)\" AND account_id = \"\(acDetail.ac_AccountId)\"  AND account_number=\"\(accid)\";"
        let updateStatementString = "UPDATE sf_user_account SET trusted_device_key=\"\(self.genrateTrustKey())\",account_verify_date=\"\(self.currentDateTime())\",trusted_device_expration_date = \"\(expiryDate)\",account_user_image=\"\(userimage)\" WHERE user_id = \"\(uid)\" AND account_number=\"\(accNumber)\";"
        var updateStatement: COpaquePointer = nil
        if sqlite3_prepare_v2(connect(), updateStatementString, -1, &updateStatement, nil) == SQLITE_OK {
            if sqlite3_step(updateStatement) == SQLITE_DONE {
                
                success = "yes"
            } else {
                success = "no"
            }
        } else {
            print("UPDATE statement could not be prepared")
        }
        sqlite3_finalize(updateStatement)
        sqlite3_close(connect())
        
        return success
    }
    
    
    func getWebserviceURL(appendLink:NSString) -> NSString {
        
        return API.BASE_URL.stringByAppendingString(appendLink as String)
    }
    
    /*
     Funaction Name:func currentDateTime
     Purpose : get system current date and time
     Parameter : NULL
     Return : NSString dateformatter.stringFromDate(NSDate())
     */
    
    func currentDateTime() -> NSString {
        
        let date = NSDate()
        let dateFormatter = NSDateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        let dateString = dateFormatter.stringFromDate(date)
        print(dateString)
        return dateString
        
    }
    
    /*
     Funaction Name:func IMEIString
     Purpose : get system device IMEI number
     Parameter : NULL
     Return : String (UIDevice.currentDevice().identifierForVendor?.UUIDString)!
     */

    func IMEIString() -> String {
        
        print((UIDevice.currentDevice().identifierForVendor?.UUIDString)!)
        print(UIDevice.currentDevice().identifierForVendor?.UUIDString)
        return (UIDevice.currentDevice().identifierForVendor?.UUIDString)!
    }
    /*
     Funaction Name:trustDeviceFor30Days
     Purpose : Generate date and 30 days in the current date
     Parameter : NULL
     Return : String (UIDevice.currentDevice().identifierForVendor?.UUIDString)!
     */
    func trustDeviceFor30Days() -> String {
        let date = NSCalendar.currentCalendar().dateByAddingUnit(.Day, value: 30, toDate: NSDate(), options: [])!
        let dateFormatter = NSDateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        let dateString = dateFormatter.stringFromDate(date)
        print(dateString)
        return dateString
    }
    
    func currentLatLong() -> Void {
       
        startLocation = nil
        self.locationManager = CLLocationManager()
        self.locationManager.delegate = self;
        self.locationManager.distanceFilter = kCLDistanceFilterNone
        self.locationManager.desiredAccuracy = kCLLocationAccuracyBest
        self.locationManager.requestAlwaysAuthorization()
        self.locationManager.startUpdatingLocation()
        
    }
    func locationManager(manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let locValue:CLLocationCoordinate2D = manager.location!.coordinate
        print("locations = \(locValue.latitude) \(locValue.longitude)")
        
        user.currentLat = String(locValue.latitude)
        user.currentLong = String(locValue.longitude)
        self.locationManager.stopUpdatingLocation()
    }

    
       /*
     Funaction Name:dateAndTimeStamp
     Purpose : Generate current date and current timestamp. This function called when user do image verification
     Parameter : NULL
     Return : String (UIDevice.currentDevice().identifierForVendor?.UUIDString)!
     */
    
    func dateAndTimeStamp() -> String {
            let date = NSDate()
            let dateFormatter = NSDateFormatter()
            dateFormatter.dateFormat = "dd_MM_yyyy_hh_mm_ss"
       // dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss"
            let dateString = dateFormatter.stringFromDate(date)
            print(dateString)
            return dateString
     //2016-06-10T10:00:00
        //"yyyy-MM-dd'T'HH:mm:ss'Z'"
        
    }
    


    func genrateTrustKey() -> NSString {
        let temp = StringToSHA1()
        var userid:String!
        var accountid:String!
        var email:String!
        var phone:String!
        var IMEI:String!
        var str:String!
        
        var sha1Key:NSString!
        if (NSUserDefaults.standardUserDefaults().stringForKey("trustDevice") != nil) {
            if acDetail.isAudio {
                userid = String(acDetail.ac_UserId)
                accountid = String(acDetail.ac_AccountId)
                email = String(acDetail.ac_email)
                phone = String(acDetail.ac_phoneNum)
                IMEI = gblAppDelegate.IMEIString()
                str = userid + "" + accountid + "" + email + "" + phone + "" + IMEI
                sha1Key = temp.stringToSha1(str)
                user.expiryDate = gblAppDelegate.trustDeviceFor30Days()
                
            }else{
                userid = String(user.userId)
                accountid = String(user.accountId)
                email = String(user.userEmail)
                phone = String(user.userPhone)
                IMEI = gblAppDelegate.IMEIString()
                str = userid + "" + accountid + "" + email + "" + phone + "" + IMEI
                sha1Key = temp.stringToSha1(str)
                user.expiryDate = gblAppDelegate.trustDeviceFor30Days()
            }
            
            
        }else{
            sha1Key = "nokey"
            user.expiryDate = gblAppDelegate.currentDateTime() as String
        }
        return sha1Key
    }
    func initilizeWebServices(email:String,phone:String,accout:String) ->Void {
        if NSUserDefaults.standardUserDefaults().stringForKey("isregister") == "yes" {

            if API.IS_API_CALL{
                if API.NetworkIsReachable() == "YES" {
                    var aDict:NSDictionary!
                    let SIFI = SimplifideLibrary(baseUrl: API.BASE_URL,apiKey: API.API_KEY,apiSecret: API.API_SECRET)
                
                    aDict =  SIFI.callWebServicesForRegisterUser(email, phone: phone, accountNum: accout)
                    print(aDict)
                        if (aDict.valueForKey("status"))! as! String == "false"{
                            let alertController = UIAlertController(title:"Alert" as String, message: aDict.valueForKey("code")as! String as String, preferredStyle: .Alert)
                            let yesAction = UIAlertAction(title: "OK", style: .Default) { (action) -> Void in
                            }
                            alertController.addAction(yesAction)
                            self.window?.rootViewController?.presentViewController(alertController, animated: true, completion: nil)
                        }else{
                            if (aDict.valueForKey("status"))! as! String == "Ok" && (aDict.valueForKey("code"))! as! String == "200"{
                                API.ENROLLBIOMATRIC=aDict.valueForKey("links")?.valueForKey("enrollBiometric") as! String
                                API.REQUESTEMAILVERIFICATION=aDict.valueForKey("links")?.valueForKey("requestEmailVerification") as? String
                                API.VERIFYBIOMETRIC=aDict.valueForKey("links")?.valueForKey("verifyBiometric") as? String
                                API.VERIFYEMAIL=aDict.valueForKey("links")?.valueForKey("verifyEmail") as! String
                                API.REQUESTDEVICEVERIFICATION=aDict.valueForKey("links")?.valueForKey("requestDeviceVerification") as! String
                                API.VERIFYDEVICE=aDict.valueForKey("links")?.valueForKey("verifyDevice") as? String
                            }
                        } 
                    
                    
                }else{
                    let alertController = UIAlertController(title:"Alert" as String, message: API.APP_MESSAGE["NO_INTERNET"]!, preferredStyle: .Alert)
                    let yesAction = UIAlertAction(title: "OK", style: .Default) { (action) -> Void in
                    }
                    alertController.addAction(yesAction)
                    self.window?.rootViewController?.presentViewController(alertController, animated: true, completion: nil)
                }
            }else{
                return
            }
        }else{
            return
        }

    }
    func applicationDidBecomeActive(application: UIApplication) {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
        
    }
}



